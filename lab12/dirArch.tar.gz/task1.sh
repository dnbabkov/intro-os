nflag=""
Cflag="-i"
while getopts i:o:p:Cn optletter; do
    case $optletter in
	i) ival=$OPTARG;;
	o) oval=$OPTARG;;
	p) pval=$OPTARG;;
	C) Cflag="";;
	n) nflag="-n";;
	*) echo Illegal option $optletter
    esac
done

if [ -z $ival ]; then
    echo "No input file"; exit
fi

if [ -z $oval ]; then
    echo "No output file"; exit
fi

if [ -z $pval ]; then
    echo "No pattern"; exit
fi

grep $nflag $Cflag $pval $ival > $oval