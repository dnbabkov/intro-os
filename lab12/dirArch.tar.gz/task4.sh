path=$1
arcName="dirArch.tar"

if [ -z $path ]; then
    echo "No path"
    exit
fi

tar -cvf $arcName -T /dev/null
tar -rvf $arcName `find $path -type f -mtime -7 -not -name "$arcName*"`

gzip $arcName