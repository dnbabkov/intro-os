num=0
while getopts c:d ol
do
case $ol in
    c)num=$OPTARG;;
    d)del=true;;
    *)echo "Wait, that's illegal!"
esac
done

if [ $num -gt 0 ]
then for (( i=1; i<=$num; i++ ))
    do
	touch ${i}.tmp
    done
fi

if [ "$del" = true ]
then rm *.tmp
fi