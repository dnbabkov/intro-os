backup=~/backup				#Переменной присваивается путь в директорию backup
tar -zcvf ${backup}/back.gz task1.sh	#Выполняется копирование с архивированием этого набора команд в архив back.gz